import wheels.users.*;

public class Car {
	private Rectangle body, roof;
	private Ellipse wheel_front, wheel_back;

	public Car(int x, int y) {
		body = new Rectangle(java.awt.Color.black);
		body.setSize(80, 20);
		body.setLocation(10,20);
		
		roof = new Rectangle(java.awt.Color.black);
		roof.setSize(40, 20);
		roof.setLocation(30, 7);
		
		wheel_front = new Ellipse(java.awt.Color.gray);
		wheel_front.setSize(15, 15);
		wheel_front.setLocation(25,35);
		
		wheel_back = new Ellipse(java.awt.Color.gray);
		wheel_back.setSize(15, 15);
		wheel_back.setLocation(60,35);
	}

	public void setLocation(int x, int y) {
	}
}
