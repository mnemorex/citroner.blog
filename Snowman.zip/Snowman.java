import wheels.users.*;

public class Snowman {
	private Ellipse _head, _body, _leftEye, _rightEye;
	
	public Snowman(int x, int y) {
		_body = new Ellipse(java.awt.Color.white);
		_body.setSize(100, 100);
		_head = new Ellipse(java.awt.Color.white);
		_head.setSize(80, 80);
		_leftEye = new Ellipse(java.awt.Color.black);
		_leftEye.setSize(15, 15);
		_rightEye = new Ellipse(java.awt.Color.black);
		_rightEye.setSize(15, 15);

		_body.setLocation(10,300);
		_head.setLocation(20,240);
		_leftEye.setLocation(35,265);
		_rightEye.setLocation(75,265);
		setOutline(java.awt.Color.black, 2);
		
		setLocation(x, y);
	}
	
	public void setLocation(int x, int y) {
		_body.setLocation(_body.getXLocation() + x, _body.getYLocation() + y);
		_head.setLocation(_head.getXLocation() + x, _head.getYLocation() + y);
		_leftEye.setLocation(_leftEye.getXLocation() + x, _leftEye.getYLocation() + y);
		_rightEye.setLocation(_rightEye.getXLocation() + x, _rightEye.getYLocation() + y);
	}

	public void setOutline (java.awt.Color color, int thickness) {
		_body.setFrameColor(color);
		_body.setFrameThickness(thickness);
		_head.setFrameColor(color);
		_head.setFrameThickness(thickness);
	}
}


