import wheels.users.*;

public class Hat {
	private Rectangle _hatBrim, _hatUpper;

	public Hat() {
		_hatBrim = new Rectangle(java.awt.Color.black);
		_hatBrim.setSize(80, 20);
		_hatUpper = new Rectangle(java.awt.Color.black);
		_hatUpper.setSize(60, 60);
	}

	public void setLocation(int x, int y) {
		_hatBrim.setLocation(20 + x, y + 50 + 180);
		_hatUpper.setLocation(x + 10 + 20, y + 180);
	}
}
