
import wheels.users.*;

public class SnowCartoon extends Frame {
	private Snowman  _snowman1;
	private Hat _hat1;
	private ConversationBubble _bubble1;

	private Snowman  _snowman2;
	private Hat _hat2;
	private ConversationBubble _bubble2;
	
	private Ellipse _sun;
	private Car car;

	public SnowCartoon() {
		_sun = new Ellipse(java.awt.Color.cyan);
		_sun.setLocation (500, 40);
		_sun.setSize(60, 60);
		
		{	
			final int x = 140;
			final int y = -10;
			_snowman1 = new Snowman(x, y);
			_hat1 = new Hat();
			_hat1.setLocation(x, y);
		
			_bubble1 = new ConversationBubble("Ho Ho", ConversationBubble.TAIL_DIR_LEFT);
			_bubble1.setLocation(x + 110, y + 110);
		}
		
		{	
			final int x = 40;
			final int y = -100;
			_snowman2 = new Snowman(x, y);
			_hat2 = new Hat();
			_hat2.setLocation(x, y);
		
			_bubble2 = new ConversationBubble("Ho Ho", ConversationBubble.TAIL_DIR_LEFT);
			_bubble2.setLocation(x + 110, y + 110);
		}
		
		car = new Car(0,0);
	}

	public static void main ( String[] argv ) {
		SnowCartoon cartoon = new SnowCartoon();
	}

}
